class AppointmentsPage {
    //----------------- Locators -----------------//
    appointmentsHeader = "div[class='MuiGrid-root MuiGrid-item MuiGrid-grid-xs-true']>span[class*='MuiBox-root']>span"
    upcomingTab = "div[class='MuiTabs-scroller MuiTabs-fixed'] button:nth-child(1)"
    newScheduleAppointmentButton = "svg[title='Schedule Appointment']"
    pastAppointmentTab = "div[class='MuiTabs-scroller MuiTabs-fixed'] button:nth-child(2)"
    pastAppointmentList = "div[class*='mobileViewList']>div"
    appointmentDetailsHeader = "div[class='MuiGrid-root MuiGrid-container']>div:nth-child(2)>div"
    appointmentForName = "div[class*='appointment-form_detailsContainer__'] div[role='pointer']"
    firstAppointment = "div[class*='mobileViewList']>div:nth-child(1) div[style*='overflow-wrap:']"
    appointmentDetailsBackButton = "div[class='MuiGrid-root MuiGrid-container'] button"
    appointmentStatusList = "div[class*='mobileViewList'] div[class='MuiGrid-root MuiGrid-container']>div:nth-child(1) span"
    appointmentDetailsViewAppointmentStatusVal = "div[class*='appointment-form_detailsContainer'] div[class*='appointment-form_detailsView']:nth-child(1) span"
    rescheduleAppointmentCommentInputbox = "input#comment"
    rescheduleAppointmentButtons = ".MuiDialogActions-root>button"  //".MuiDialogActions-root>button>span:nth-child(1)"
    appointmentRescheduleButton = "div[class*='appointment-form_detailsView']:nth-child(2)>div>div:nth-child(1)>div:nth-child(3)>button:nth-child(1)"
    rescheduleAppointmentCancelButton = ".MuiDialogActions-root>button:nth-child(1)>span:nth-child(1)"
}
module.exports = AppointmentsPage;