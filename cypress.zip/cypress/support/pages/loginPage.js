class LoginPage {

  //----------------- Locators -----------------//
  userNameInputField = "input#username"
  passwordInputField = "input#password"
}

module.exports = LoginPage;