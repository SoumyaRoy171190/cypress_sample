// <reference types="cypress" />

const LoginPage = require('../../support/pages/loginPage')
let loginPage

describe("test Patient-App Payer version", async function() {
  beforeEach(() => {
    cy.visit('https://www.myhealthrecord.healthcare/launch')
    loginPage = new LoginPage()
  })

  it('login validation of Patient-App Payer version', async function () {
    cy.enterDataInInputBox(loginPage.userNameInputField, 'patient1')
  })
})