// <reference types="cypress" />

describe('Patient-App Regression scenarios', async function () {
    const HomePage = require('../../support/pages/homePage')
    const AppointmentsPage = require('../../support/pages/appointmentsPage')
    const LoginPage = require('../../support/pages/loginPage')
    let homePage
    let appointmentsPage
    let loginPage
  
    beforeEach(() =>{
    //   cy.visit(Cypress.env(''))
      cy.visit('https://www.myhealthrecord.healthcare/launch')
      cy.fixture('example').then(function (data) {
        this.data = data
      })
      homePage = new HomePage()
      appointmentsPage = new AppointmentsPage()
      loginPage = new LoginPage()
    })

    it('verify login to Paitent-App Payer version', async function () {
      cy.enterDataInInputBox(loginPage.userNameInputField, 'patient1')
    })
})