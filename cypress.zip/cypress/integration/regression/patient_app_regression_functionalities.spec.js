// <reference types="cypress" />

describe('Patient-App Regression scenarios', async function () {

  const HomePage = require('../../support/pages/homePage')
  const AppointmentsPage = require('../../support/pages/appointmentsPage')
  let homePage;
  let appointmentsPage

  beforeEach(() =>{
    cy.visit(Cypress.env('baseUrl'))
    cy.fixture('example').then(function (data) {
      this.data = data
    })
    homePage = new HomePage()
    appointmentsPage = new AppointmentsPage()
  })

  it("cancel reschedule appointment - Patient-App", async function () {
    // verify Home page navigation
    cy.verifyElementPropertyAndValueIncluded(homePage.homePageImageLink, 'src', this.data.logoName)

    // Navigating to Appointments
    cy.clickOnElement(homePage.appointmentsLink)

    // validate Appointments page
    cy.url().should('include', '/appointments')
    cy.checkElementVisibilityWithText(appointmentsPage.appointmentsHeader, this.data.appointmentsHeader)
    cy.checkElementVisibilityWithTextAndSelected(appointmentsPage.upcomingTab, this.data.upcomingTab)
    cy.checkVisibilityOfElement(appointmentsPage.newScheduleAppointmentButton)
    cy.checkElementVisibilutyWithTextAndNotSelected(appointmentsPage.pastAppointmentTab, this.data.pastTab)
    cy.clickOnElement(appointmentsPage.pastAppointmentTab)
    cy.wait(5000)
    cy.clickLinkFromOtionsList(appointmentsPage.appointmentStatusList, 'Confirmed')
    // Verify Appointment details
    cy.checkVisibilityOfElement(appointmentsPage.appointmentDetailsHeader)
    cy.checkElementVisibilityWithText(appointmentsPage.appointmentDetailsViewAppointmentStatusVal, 'Appointment Confirmed')
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'RESCHEDULE')
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'CANCEL')
    cy.checkVisibilityOfWebElementWithSpecificText('div', 'Woundcare')
    cy.checkVisibilityOfWebElementWithSpecificText('h6', 'Covid screening')
    // click on Reschedule Button
    cy.clickOnElementWithText('button', 'RESCHEDULE')
    cy.clickOnElement(appointmentsPage.appointmentRescheduleButton)
    // veirfy Reschedule Appointment popup
    cy.checkVisibilityOfWebElementWithSpecificText('h2', 'Reschedule Appointment')
    cy.enterDataInInputBox(appointmentsPage.rescheduleAppointmentCommentInputbox, this.data.rescheduleAppointmentComment)
    cy.clickOnElement(appointmentsPage.rescheduleAppointmentCancelButton)
    // Verify Appointment details -- Post cancelling Reshedule Appointment
    cy.checkVisibilityOfElement(appointmentsPage.appointmentDetailsHeader)
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'RESCHEDULE')
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'CANCEL')

  })

  it("confirm reschedule appointment submission - Patien-App", async function () {
    // verify Home page navigation
    cy.verifyElementPropertyAndValueIncluded(homePage.homePageImageLink, 'src', this.data.logoName)

    // Navigating to Appointments
    cy.clickOnElement(homePage.appointmentsLink)

    // validate Appointments page
    cy.url().should('include', '/appointments')
    cy.checkElementVisibilityWithText(appointmentsPage.appointmentsHeader, this.data.appointmentsHeader)
    cy.checkElementVisibilityWithTextAndSelected(appointmentsPage.upcomingTab, this.data.upcomingTab)
    cy.checkVisibilityOfElement(appointmentsPage.newScheduleAppointmentButton)
    cy.checkElementVisibilutyWithTextAndNotSelected(appointmentsPage.pastAppointmentTab, this.data.pastTab)
    cy.clickOnElement(appointmentsPage.pastAppointmentTab)
    cy.wait(5000)
    cy.clickLinkFromOtionsList(appointmentsPage.appointmentStatusList, 'Confirmed')
    // Verify Appointment details
    cy.checkVisibilityOfElement(appointmentsPage.appointmentDetailsHeader)
    cy.checkElementVisibilityWithText(appointmentsPage.appointmentDetailsViewAppointmentStatusVal, 'Appointment Confirmed')
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'RESCHEDULE')
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'CANCEL')
    cy.checkVisibilityOfWebElementWithSpecificText('div', 'Woundcare')
    cy.checkVisibilityOfWebElementWithSpecificText('h6', 'Covid screening')
    // click on Reschedule Button
    cy.clickOnElementWithText('button', 'RESCHEDULE')
    cy.clickOnElement(appointmentsPage.appointmentRescheduleButton)
    // veirfy Reschedule Appointment popup
    cy.checkVisibilityOfWebElementWithSpecificText('h2', 'Reschedule Appointment')
    cy.enterDataInInputBox(appointmentsPage.rescheduleAppointmentCommentInputbox, this.data.rescheduleAppointmentComment)
    cy.clickOnButtonsBasedOnIndex(appointmentsPage.rescheduleAppointmentButtons, 1)
    // Verify Appointment details -- Post Submitting Reshedule Appointment
    cy.checkVisibilityOfElement(appointmentsPage.appointmentDetailsHeader)
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'RESCHEDULE')
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'CANCEL')
  })

  it("cancelling cancel-appointment - Patient-App", async function () {
    // verify Home page navigation
    cy.verifyElementPropertyAndValueIncluded(homePage.homePageImageLink, 'src', this.data.logoName)

    // Navigating to Appointments
    cy.clickOnElement(homePage.appointmentsLink)

    // validate Appointments page
    cy.url().should('include', '/appointments')
    cy.checkElementVisibilityWithText(appointmentsPage.appointmentsHeader, this.data.appointmentsHeader)
    cy.checkElementVisibilityWithTextAndSelected(appointmentsPage.upcomingTab, this.data.upcomingTab)
    cy.checkVisibilityOfElement(appointmentsPage.newScheduleAppointmentButton)
    cy.checkElementVisibilutyWithTextAndNotSelected(appointmentsPage.pastAppointmentTab, this.data.pastTab)
    cy.clickOnElement(appointmentsPage.pastAppointmentTab)
    cy.wait(5000)
    cy.clickLinkFromOtionsList(appointmentsPage.appointmentStatusList, 'Confirmed')
    // Verify Appointment details
    cy.checkVisibilityOfElement(appointmentsPage.appointmentDetailsHeader)
    cy.checkElementVisibilityWithText(appointmentsPage.appointmentDetailsViewAppointmentStatusVal, 'Appointment Confirmed')
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'RESCHEDULE')
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'CANCEL')
    cy.checkVisibilityOfWebElementWithSpecificText('div', 'Woundcare')
    cy.checkVisibilityOfWebElementWithSpecificText('h6', 'Covid screening')
    // click on Cancel Button
    cy.clickOnElementWithText('button', 'CANCEL')
    // veirfy Reschedule Appointment popup
    cy.checkVisibilityOfWebElementWithSpecificText('h2', 'Cancel Appointment')
    cy.enterDataInInputBox(appointmentsPage.rescheduleAppointmentCommentInputbox, this.data.cancelAppointmentComment)
    cy.clickOnButtonsBasedOnIndex(appointmentsPage.rescheduleAppointmentButtons, 0)
    // Verify Appointment details -- Post cancelling Cancel Appointment
    cy.checkVisibilityOfElement(appointmentsPage.appointmentDetailsHeader)
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'RESCHEDULE')
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'CANCEL')
  })

  it("perform cancel appointment - Patient-App", async function () {
    // verify Home page navigation
    cy.verifyElementPropertyAndValueIncluded(homePage.homePageImageLink, 'src', this.data.logoName)

    // Navigating to Appointments
    cy.clickOnElement(homePage.appointmentsLink)

    // validate Appointments page
    cy.url().should('include', '/appointments')
    cy.checkElementVisibilityWithText(appointmentsPage.appointmentsHeader, this.data.appointmentsHeader)
    cy.checkElementVisibilityWithTextAndSelected(appointmentsPage.upcomingTab, this.data.upcomingTab)
    cy.checkVisibilityOfElement(appointmentsPage.newScheduleAppointmentButton)
    cy.checkElementVisibilutyWithTextAndNotSelected(appointmentsPage.pastAppointmentTab, this.data.pastTab)
    cy.clickOnElement(appointmentsPage.pastAppointmentTab)
    cy.wait(5000)
    cy.clickLinkFromOtionsList(appointmentsPage.appointmentStatusList, 'Confirmed')
    // Verify Appointment details
    cy.checkVisibilityOfElement(appointmentsPage.appointmentDetailsHeader)
    cy.checkElementVisibilityWithText(appointmentsPage.appointmentDetailsViewAppointmentStatusVal, 'Appointment Confirmed')
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'RESCHEDULE')
    cy.checkVisibilityOfWebElementWithSpecificText('button', 'CANCEL')
    cy.checkVisibilityOfWebElementWithSpecificText('div', 'Woundcare')
    cy.checkVisibilityOfWebElementWithSpecificText('h6', 'Covid screening')
    // click on Cancel Button
    cy.clickOnElementWithText('button', 'CANCEL')
    // veirfy Reschedule Appointment popup
    cy.checkVisibilityOfWebElementWithSpecificText('h2', 'Cancel Appointment')
    cy.enterDataInInputBox(appointmentsPage.rescheduleAppointmentCommentInputbox, this.data.cancelAppointmentComment)
    cy.clickOnButtonsBasedOnIndex(appointmentsPage.rescheduleAppointmentButtons, 1)
  })
})